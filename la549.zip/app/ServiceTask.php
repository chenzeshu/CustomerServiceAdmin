<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServiceTask extends Model
{
    protected $guarded=[];

}
