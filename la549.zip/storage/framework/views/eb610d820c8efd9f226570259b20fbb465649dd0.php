

<?php $__env->startSection('content'); ?>
    <div class="container tasks-styl">
        <v-services :services="<?php echo e($services); ?>" :contract_id="<?php echo e($id); ?>" :stype="0"></v-services>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
    <script>
        //不放jq初始化里，因为太慢了。
        //第二个参数为默认值
        var oPosition = loadFromLocal('serviceposition',1)
        $('a[role="tab"][data-content='+ oPosition +']').click()

        //tab栏位置存档
        function goPosition(e) {
            var position = $(e).data('content')
            saveToLocal('serviceposition', position)
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>