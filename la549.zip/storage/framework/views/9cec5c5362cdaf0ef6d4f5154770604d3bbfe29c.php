
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-2">
                <h3>客户联系人</h3>&nbsp;
            </div>
            
            <div class="col-sm-6" style="margin-top:20px">
                <div class="inner-project-modal float-left">
                    <?php echo $__env->make('customer2s.createCustomerModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <form action="<?php echo e(asset('searchcus2name')); ?>" method="POST" class="float-left">
                    <?php echo e(csrf_field()); ?>

                    <input type="text" name="searchcus2name">
                    <button class="btn btn-default btn-sm">搜索联系人</button>
                </form>
            </div>
        </div>
        <hr>
        <div class="row">
            <table class="table table-striped table-hover">
                <thead>
                <tr>
                    <th>联系人姓名</th>
                    <th>联系方式</th>
                    <th>所属单位</th>
                    <th class="text-center" colspan="2">操作</th>
                </tr>
                </thead>
                <tbody>
                <?php if($customer2s): ?>
                    <?php $__currentLoopData = $customer2s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customer->name); ?></td>
                            <td><?php echo e($customer->phone); ?></td>
                            <td><?php echo e($customer->customer_name); ?></td>
                            <td>
                              <ul>
                                  <div class="float-left">
                                      <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editModal-<?php echo e($customer->id); ?>">
                                          <i class="fa fa-btn fa-cog"></i>
                                      </button>
                                  </div>
                                  <div class="float-left">
                                      <?php echo $__env->make('customer2s.deleteCustomer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                  </div>
                              </ul>
                            </td>
                        </tr>
                        <?php echo $__env->make('customer2s.editCustomerModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="row">

            <div class="clearfix"></div>
            <div class="container">
                <div class="service-index-page">
                    <?php echo e($customer2s->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('customerJS'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>