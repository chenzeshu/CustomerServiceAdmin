<!-- Modal -->
<div class="modal fade" id="editModal-<?php echo e($customer->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="editModal-<?php echo e($customer->id); ?>">修改联系人信息</h4>
            </div>
            <?php echo Form::model($customer, ['route'=>['customer2sblade.update',$customer->id],'files'=>true,'method'=>'PATCH']); ?>

            <div class="modal-body">
                <div class="form-group">
                    <?php echo Form::label('name','联系人名称：',['class'=>'control-label']); ?>

                    <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('phone','联系方式：',['class'=>'control-label']); ?>

                    <?php echo Form::text('phone',null,['class'=>'form-control']); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::label('customer_name','客户单位：',['class'=>'control-label']); ?>

                    <?php echo Form::text('customer_name',null,['class'=>'form-control']); ?>

                </div>
                <?php echo $__env->make('errors.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">提交</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>


    
        
        
        
            
            
            
            
            
        
        
            
        
    
