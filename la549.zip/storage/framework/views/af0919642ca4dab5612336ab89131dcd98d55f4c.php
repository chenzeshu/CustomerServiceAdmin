

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <h3>新建角色</h3>
                    <?php echo Form::open(['method'=>'post', 'route'=>'roles.store']); ?>

                    <?php echo $__env->make('auth.roles._createForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="checkbox">
                        <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label for="">
                                <?php echo Form::checkbox('perm[]', $perm->id, false); ?>

                                <?php echo e(isset($perm->display_name) ? $perm->display_name : $perm->name); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::submit('新建角色', ['class'=>'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3>新建权限</h3>
                    <?php echo Form::open(['method'=>'post', 'route'=>'permissions.store']); ?>

                    <?php echo $__env->make('auth.roles._createForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <div class="form-group">
                        <?php echo Form::submit('新建权限', ['class'=>'btn btn-primary']); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <div class="col-md-9">
            <?php echo $__env->make('auth.roles._rolePanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>