

<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-striped">
            <thead>
            <tr>
                <th>序号</th>
                <th>员工id</th>
                <th>服务id</th>
                <th>职责</th>
                <th>发生时间</th>
            </tr>
            </thead>
            <tbody>
            <?php if($duties): ?>
                <?php $__currentLoopData = $duties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($duty->id); ?></td>
                        <td><?php echo e($duty->user_id); ?></td>
                        <td><?php echo e($duty->service_id); ?></td>
                        <td><?php echo e($duty->duty); ?></td>
                        <td><?php echo e($duty->created_at->diffForHumans()); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
    <script>
        $(function () {
            toggleBar()
            setInterval(setHeight, 500)
        })

        function toggleBar(){
            $('.icon-bar').hide()
            $('.thumbnail').hover(function () {
                $(this).find('.icon-bar').toggle()
            })
        }
        function setHeight() {
            var cHeight = $('.cus-hook:first').height()
            if (cHeight){
                $('.inner-project-modal').height(cHeight-48);
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>