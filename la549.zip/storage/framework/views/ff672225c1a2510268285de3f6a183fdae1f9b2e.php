

<?php $__env->startSection('content'); ?>
    <div class="container tasks-styl">


        <div>
            <!-- Nav tabs -->
            <ul id="myTabs" class="nav nav-tabs" role="tablist">
                <li role="presentation">
                    <a href="#contracttab" aria-controls="settings" role="tab" data-toggle="tab" data-content="1"
                       onclick="goPosition(this)">合同</a>
                </li>
                <li role="presentation">
                    <a href="#cus2" aria-controls="settings" role="tab" data-toggle="tab" data-content="2"
                       onclick="goPosition(this)">客户联系人</a>
                </li>
            </ul>
            <div id="myTabContent" class="tab-content">
                <div role="tabpanel" class="tab-pane" id="contracttab">
                    <v-contracts :fresh-contracts="<?php echo e($contracts); ?>" :parent-id="<?php echo e($id); ?>"></v-contracts>
                </div>
                
                <div role="tabpanel" class="tab-pane" id="cus2">
                    <v-customer2 :cus2s="<?php echo e($cus2s); ?>"></v-customer2>
                </div>
            </div>
        </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
    <script>
        //不放jq初始化里，因为太慢了。
        //默认选择客服在保（4）
        var oPosition = loadFromLocal('position',1)
        $('a[role="tab"][data-content='+ oPosition +']').click()


        //tab栏位置存档
        function goPosition(e) {
            var position = $(e).data('content')
            saveToLocal('position', position)
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>