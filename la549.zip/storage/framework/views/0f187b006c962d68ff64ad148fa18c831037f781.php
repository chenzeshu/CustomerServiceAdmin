
    <div class="form-group">
        <?php echo Form::label('name', '名称', ['class'=>'control-label']); ?>

        <?php echo Form::text('name', null, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('display_name', '显示名称', ['class'=>'control-label']); ?>

        <?php echo Form::text('display_name', null, ['class'=>'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('description', '描述', ['class'=>'control-label']); ?>

        <?php echo Form::text('description', null, ['class'=>'form-control']); ?>

    </div>
