<?php echo Form::open(['route'=>['customers.destroy', $customer->id], 'method' => 'delete']); ?>

<button type="submit" class="btn">
    <i class="fa fa-btn fa-close"></i>
</button>
<?php echo Form::close(); ?>