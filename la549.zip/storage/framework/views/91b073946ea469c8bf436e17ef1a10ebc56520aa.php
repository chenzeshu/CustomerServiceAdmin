<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
        <div class="panel <?php echo e($role->name == 'admin' ? 'panel-success':'panel-default'); ?>">

            <div class="panel-heading">
                <div class="pull-left">
                    <i class="fa fa-btn fa-user"></i>
                    <?php echo e(isset($role->display_name) ? $role->display_name : $role->name); ?>

                </div>

                    
                    
                    <?php if (\Entrust::ability('admin', 'delete_role', ['validate_all' =>true])) : ?>
                        <?php echo $__env->make('auth.roles._deleteForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; // Entrust::ability ?>


                    <?php if (\Entrust::ability('admin','edit_role')) : ?>
                        <?php echo $__env->make('auth.roles._editRoleModal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; // Entrust::ability ?>
                <div class="clearfix"></div>
            </div>

            <div class="panel-body">
                <ul class="fa-ul">
                    <?php $__currentLoopData = $role->perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <i class="fa-li fa fa-tag"></i>
                            <?php echo e(isset($perm->display_name) ? $perm->display_name : $perm->name); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php if($role->description): ?>
                <div class="panel-footer">
                    <?php echo e($role->description); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>