<!-- Button trigger modal -->
<button type="button" class="role-btn btn btn-sm pull-right"  data-toggle="modal" data-target="#editRoleModal-<?php echo e($role->id); ?>">
    <i class="fa fa-btn fa-cog"></i>
</button>

<!-- Modal -->
<div class="modal fade" id="editRoleModal-<?php echo e($role->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editRoleModal-<?php echo e($role->id); ?>-Label">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">编辑角色</h4>
            </div>
            <div class="modal-body">
                <?php echo Form::model($role, ['method'=>'patch', 'route'=>['roles.update', $role->id]]); ?>

                    <?php echo $__env->make('auth.roles._createForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="checkbox">
                    <?php $__currentLoopData = $perms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label for="">
                            <?php echo Form::checkbox('perm[]', $perm->id, permCheck($perm, $role)); ?>

                            <?php echo e(isset($perm->display_name) ? $perm->display_name : $perm->name); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
                    <?php echo Form::submit('保存编辑' ,['class'=>'btn btn-primary']); ?>

                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>

    </div>
</div>