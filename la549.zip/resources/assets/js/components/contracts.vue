<template>
    <div class="contracts">
        <div class="newContract" @click="toggleNew">
            <i class="fa fa-btn fa-plus"></i>
        </div>
        <table class="table table-striped">
            <thead class="self-font-weight-700 text-center">
                <tr>
                    <td width="100"><span v-if="type===0">销售</span><span v-else>客服</span>合同编号</td>
                    <td width="300">合同名称</td>
                    <td width="100">项目经理</td>
                    <td width="100">技术经理</td>
                    <td width="200">合同金额（元）</td>
                    <td>状态&nbsp;&nbsp;<i class="fa fa-btn fa-caret-square-o-down touch" @click="sort"></i></td>
                    <td colspan="2">操作</td>
                </tr>
            </thead>
            <tbody class="text-center">
                <tr v-for="contract of contracts">
                    <td>{{contract.contract_id}}</td>
                    <td><a :href="'/contracts/'+ contract.id ">{{contract.name}}</a></td>
                    <td><span v-for="p in contract.pm">{{ p.name }}</span></td>
                    <td><span v-for="t in contract.tm">{{ t.name }}</span></td>
                    <td>{{contract.sum}}</td>
                    <td v-if="contract.active ==0">
                        <span v-if="contract.time2 < nowaday" style="color:red">过保</span>
                        <span v-if="contract.time2 >= nowaday" style="color:green">在保</span>
                    </td>
                    <td v-if="contract.active ==1">维保</td>
                    <td class="contract-item-edit">
                         <i class="fa fa-btn fa-cog" @click="toggleEdit(contract)"></i>
                         <i class="fa fa-btn fa-close" @click="deleteConfirmContract(contract)"></i>
                    </td>
                </tr>
            </tbody>
        </table>
        <!--新建-->
        <transition name="fade">
            <div class="new-wrapper" v-show="newFlag">
                <div class="modal-header">
                    <button type="button" class="close" @click="toggleNew"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">新建合同</h4>
                </div>
                <br>
                <form  @submit.prevent="addContract()"
                       class="form-horizontal width-80per-margin-auto">
                    <!--合同名称-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">合同名称</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-12">
                                    <input type="text" class="form-control" v-model="newContract.name">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--项目经理-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">项目经理</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-8">
                                    <addman :type="1" :men="newContract.pm"></addman>
                                    <!--<input type="text" class="form-control" v-model="newContract.pm">-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--技术经理-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">技术经理</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-8">
                                    <addman :type="3" :men="newContract.tm"></addman>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同金额-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">合同金额</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-12">
                                    <input type="text" class="form-control" v-model="newContract.sum" placeholder="自动保留二位小数">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同类型radio-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">合同状态</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10 form-inline">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="type" value="0" v-model="newContract.type">
                                            销售签
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="type" value="1" v-model="newContract.type">
                                            客服签
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同开始日期-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">开始日期</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10">
                                    <el-date-picker
                                            v-model="newContract.time1" type="date" placeholder="选择回访日期"
                                            :format="datepicker.format"
                                            :size="datepicker.size" :editable="datepicker.editable">
                                    </el-date-picker>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同截至日期-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">截止日期</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10">
                                    <el-date-picker
                                            v-model="newContract.time2" type="date" placeholder="选择回访日期"
                                            :format="datepicker.format"
                                            :size="datepicker.size" :editable="datepicker.editable">
                                    </el-date-picker>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--维保状态radio-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">合同状态</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10 form-inline">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="bao" value="0" v-model="newContract.active">
                                            非维保
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="bao"  value="1" v-model="newContract.active">
                                            维保
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-10">
                            <button type="submit" class="btn btn-default">新建合同</button>
                        </div>
                    </div>
                </form>
            </div>
        </transition>
        <!--更新-->
        <transition name="fade">
            <div class="edit-wrapper" v-show="editFlag">
                <div class="modal-header">
                    <button type="button" class="close" @click="toggleEdit"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">编辑合同</h4>
                </div>
                <br>
                <form  @submit.prevent="updateContract(contract1)"
                        class="form-horizontal width-80per-margin-auto">
                    <!--合同名称-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">合同名称</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-12">
                                    <input type="text" class="form-control" v-model.lazy="contract1.name">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--项目经理-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">项目经理</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-8">
                                    <addman :type="1" :men="contract1.pm"></addman>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--技术经理-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">技术经理</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-8">
                                    <addman :type="3" :men="contract1.tm"></addman>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同金额-->
                    <div class="form-group">
                        <label  class="col-sm-3 control-label">合同金额</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-12">
                                    <input type="text" class="form-control" v-model.lazy="contract1.sum" placeholder="自动保留二位小数">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同开始日期-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">开始日期</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10">
                                    <el-date-picker
                                            v-model="contract1.time1" type="date" placeholder="选择回访日期"
                                            :format="datepicker.format"
                                            :size="datepicker.size" :editable="datepicker.editable">
                                    </el-date-picker>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同截至日期-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">截止日期</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10">
                                    <el-date-picker
                                            v-model="contract1.time2" type="date" placeholder="选择回访日期"
                                            :format="datepicker.format"
                                            :size="datepicker.size" :editable="datepicker.editable">
                                    </el-date-picker>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--合同状态radio-->
                    <div class="form-group">
                        <label class="col-sm-3 control-label">合同状态</label>
                        <div class="col-sm-8">
                            <div class="row">
                                <div class="col-xs-10 form-inline">
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="bao" value="0" v-model.lazy="contract1.active" lazy>
                                            在保
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="bao" value="1" v-model.lazy="contract1.active" lazy>
                                            维保
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-10">
                            <button type="submit" class="btn btn-default">提交修改</button>
                        </div>
                    </div>
                </form>
            </div>
        </transition>
    </div>
</template>

<style lang="stylus" rel="stylesheet/stylus">
    .contract-item-edit
        .fa-btn
            cursor pointer
            margin-right 5px

.contracts
    position relative
    .newContract
        position absolute
        top 0
        left 0
        width 30px
        height 30px
        .fa-btn
            cursor pointer
            margin-right 5px
    .fade-enter-active
        transition all .3s ease-in
    .fade-leave-active
        transition all .3s ease-in
        transform:translate(500px)
    .fade-enter
        transform scale3d(0.2,0.2,0.2) translateX(-500px)
        opacity 0
    .fade-leave-to
        opacity 0
    .new-wrapper
        position: fixed;
        top: 100px;
        left: 30vw;
        height: 500px;
        width: 35vw;
        background: rgba(255,255,255,0.9);
        border: 1px solid rgba(248,248,255,1);
        border-radius: 2%;
        @media screen and (max-width: 1127px)
            height 600px
    .edit-wrapper
        position: fixed;
        top: 100px;
        left: 30vw;
        height: 450px;
        width: 35vw;
        background: rgba(255,255,255,0.9);
        border: 1px solid rgba(248,248,255,1);
        border-radius: 2%;
        @media screen and (max-width: 1127px)
            height 550px


</style>

<script type="text/ecmascript">
    import Bus from '../utils/eventBus'
    import addman from './addman.vue'
    import * as base from '../utils/base'
    var cc = console.log;
    export default {
        data(){
            return {
                editFlag: false,
                newFlag: false,
                newContract:{
                    name:null,
                    pm:[],
                    tm:[],
                    sum:null,
                    type:1,  //默认选择客服
                    active:null, //默认选择在保 --》2017.3.15 变成0：非维保，1：维保
                    time1:null,
                    time2:null
                },
                contract1:{},
                datepicker:{
                    size:"small",
                    editable:false,
                    format:"yyyy-MM-dd"
                },
                nowaday:null,
                status:0, //0:显示在保，1：显示过保
            }
        },
        props:{
            parentId:{
                type:Number
            },
            type:{
               type:Number
            }, //销售还是客服
            active:{
                type:Number
            }, //过保状态
          freshContracts:{
              type:Array
          }
        },
        computed:{
            contracts(){

                let _contracts = this.freshContracts.filter((freshContract)=>{
                    return freshContract.active === this.active && freshContract.type === this.type  //箭头函数的this绑定的是设定时的上下文，也就是vue，所以不会报错
                })
                if (this.status == 1){
                    return _contracts.filter(contract=>{
                        return contract.time2 < this.nowaday
                    })
                }else{
                    return _contracts.filter(contract=>{
                        return contract.time2 > this.nowaday
                    })
                }
            },
        },
        methods:{
            sort(){
               this.status == 1? this.status = 0 :this.status = 1
            },
            toggleEdit(contract){
              this.editFlag = !this.editFlag
              if (this.editFlag){
                  this.contract1 = Object.assign({},this.contract1, contract)
              }
          },
            toggleNew(){
              this.newFlag = !this.newFlag
            },
            addContract(){
                let token = document.querySelector('meta[name=csrf-token]').getAttribute('content')
                let info = {
                    parentId: this.parentId,
                    type:this.newContract.type,
                    name : this.newContract.name,
                    pm :this.newContract.pm,
                    tm : this.newContract.tm,
                    active : this.newContract.active,
                    sum : this.newContract.sum,
                    time1: this.newContract.time1,
                    time2: this.newContract.time2
//                    _token:token
                }
//                $.post('/contracts', info, function (data) {
//                    cc(data)
//                })
                axios.post('/contracts', info).then((res)=>{
                    //todo 如果时间充足，就在外层做一个总的组件，然后用vuex解决数据更新问题
                    layer.msg("新建成功", {icon: 6});
                    setTimeout(function(){
                        location.href = location.href;
                    },900)
                    this.newFlag = false
            },error=>{
                    error.status
                    layer.msg("新建失败，请检查", {icon: 5});
                    setTimeout(function(){
                        location.href = location.href;
                    },900)
                })
            },
            updateContract(contract1){
              let data = {
                  name : contract1.name,
                  pm : contract1.pm,
                  tm : contract1.tm,
                  active : contract1.active,
                  sum : contract1.sum,
                  time1: contract1.time1,
                  time2: contract1.time2
              }
              axios.patch('/contracts/'+contract1.id, data).then((res)=>{

                  layer.msg("更新成功", {icon: 6});
                setTimeout(function(){
                    location.href = location.href;
                },900)
                this.editFlag = false
            },error=>{
                    error.status
                    layer.msg("更新失败，请检查", {icon: 5});
                    setTimeout(function(){
                        location.href = location.href;
                    },900)
                })
          },
            deleteConfirmContract(contract){
//                var _this = this
                layer.confirm('确定要删除这条合同？', {
                    btn: ['确定','取消'] //按钮
                }, ()=>{
                    this.deleteContract(contract)
                });
            },
            deleteContract(contract){
                axios.delete('/contracts/'+contract.id).then((res)=>{
                    layer.msg("删除成功", {icon: 6});
                    setTimeout(function(){
                        location.href = location.href;
                    },900)

                }, (error)=>{
                    error.status
                    layer.msg("删除失败，请检查", {icon: 5});
                    setTimeout(function(){
                        location.href = location.href;
                    },900)
                })
            },
            open() {
                this.$alert('这是一段内容', '标题名称', {
                    confirmButtonText: '确定',
                    callback: action => {
                        this.$message({
                            type: 'info',
                            message: `action: ${ action }`
                        });
                    }
                });
            }
        },
        mounted() {
            this.nowaday = Date.parse(new Date())/1000;
        },
        created(){
            //不设新事件了，直接用已有事件，  serviser对应pm,  visitor对应tm
//            2017.3.14补充：serviser type为1，visitor为3，这个同时也要写正确。
            Bus.$on('addserviser', data=>{
                if (this.newFlag){
                    this.newContract.pm = data
                }else if (this.editFlag){
                    this.contract1 = data
                }

            })
            Bus.$on('addvisitor', data=>{
                if (this.newFlag){
                    this.newContract.tm = data
                }else if (this.editFlag){
                    this.contract1 = data
                }

            })


        },
        components:{
            addman
        }
    }
</script>
