export const baseUrl = "http://222.222.228.9:8888/services/"
export const baseUrlCon = "http://222.222.228.9:8888/strange/"

// export const baseUrl = "http://lv.app/services/"
// export const baseUrlCon = "http://lv.app/strange/"