{!! Form::open(['route'=>['customer2sblade.destroy', $customer->id], 'method' => 'delete']) !!}
<button type="submit" class="btn btn-sm">
    <i class="fa fa-btn fa-close"></i>
</button>
{!! Form::close() !!}