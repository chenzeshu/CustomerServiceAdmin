
    <div class="form-group">
        {!! Form::label('name', '名称', ['class'=>'control-label']) !!}
        {!! Form::text('name', null, ['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('display_name', '显示名称', ['class'=>'control-label']) !!}
        {!! Form::text('display_name', null, ['class'=>'form-control']) !!}
    </div>
    <div class="form-group">
        {!! Form::label('description', '描述', ['class'=>'control-label']) !!}
        {!! Form::text('description', null, ['class'=>'form-control']) !!}
    </div>
